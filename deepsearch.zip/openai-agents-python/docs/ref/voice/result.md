# `Result`

::: agents.voice.result
