# `Exceptions`

::: agents.voice.exceptions
