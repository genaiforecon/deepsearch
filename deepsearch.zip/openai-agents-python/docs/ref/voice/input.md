# `Input`

::: agents.voice.input
