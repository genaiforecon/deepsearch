# `Pipeline`

::: agents.voice.pipeline
