# `Setup`

::: agents.tracing.setup
