# `Scope`

::: agents.tracing.scope
