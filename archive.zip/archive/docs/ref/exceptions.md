# `Exceptions`

::: agents.exceptions
