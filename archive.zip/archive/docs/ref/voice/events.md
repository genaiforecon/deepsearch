# `Events`

::: agents.voice.events
