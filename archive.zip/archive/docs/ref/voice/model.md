# `Model`

::: agents.voice.model
